function openFile(path) {
    anura.apps['anura.flash.handler'].open()
    const flashWindow = (anura.apps['anura.flash.handler'].windows[anura.apps['anura.flash.handler'].windows.length - 1]).content.getElementsByTagName('iframe')[0].contentWindow


    flashWindow.addEventListener('DOMContentLoaded', () => {
        const flashContainer = flashWindow.document.getElementById('flash-container');
        flashContainer.innerHTML = ''
        const ruffleScript = document.createElement('script');
        ruffleScript.src = 'ruffle.js';
        flashWindow.document.head.appendChild(ruffleScript);

        const flashObject = document.createElement('object');
        flashObject.setAttribute('data', '/fs' + path);
        flashObject.setAttribute('type', 'application/x-shockwave-flash');
        flashObject.style.width = '100%';
        flashObject.style.height = '100%';
        flashContainer.appendChild(flashObject);
    })
}
