function openFile(path) {
    anura.apps['games.emulators.n64'].open()
    const emuWindow = (anura.apps['games.emulators.n64'].windows[anura.apps['games.emulators.n64'].windows.length - 1]).content.getElementsByTagName('iframe')[0].contentWindow


    emuWindow.addEventListener('DOMContentLoaded', () => {
        anura.fs.readFile(path, async function(err, data) {
            if (err) 
                console.error(err);

            emuWindow.document.all.game.innerHTML = ""
            URL.createObjectURL(new Blob([data]))
            emuWindow.EJS_startOnLoaded = true
            emuWindow.EJS_player = '#game';
            emuWindow.EJS_gameUrl = URL.createObjectURL(new Blob([data])); // Url to Game rom
            emuWindow.EJS_core = 'n64';  // Optional core: melonds
        
            const emuJSLoader = document.createElement('script');
            emuJSLoader.src = 'loader.js';
            emuWindow.document.head.appendChild(emuJSLoader);
        })

    })
}
